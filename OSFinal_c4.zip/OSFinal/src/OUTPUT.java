import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OUTPUT {
	
	
	private List<String> out = new ArrayList<String>();
	private Set<Integer> frameSet = new HashSet<Integer>();
	private Set<Integer> pageSet = new HashSet<Integer>();
	private Double memUtilizFrames;
	private Double memUtilizWords;
	private Double dskUtilizWords;
	private Double dskUtilizFrames;
	private Double memFrag;
	private Double dskFrag;
	private Integer ioClock;
	private Integer pageFClock;
	private Integer segFClock;
	private Integer pageFNum;
	private Integer segFNum;
	public Double getMemUtilizFrames() {
		return memUtilizFrames;
	}
	public void setMemUtilizFrames(Double memUtilizFrames) {
		this.memUtilizFrames = memUtilizFrames;
	}
	public Double getMemUtilizWords() {
		return memUtilizWords;
	}
	public void setMemUtilizWords(Double memUtilizWords) {
		this.memUtilizWords = memUtilizWords;
	}
	public Double getDskUtilizWords() {
		return dskUtilizWords;
	}
	public void setDskUtilizWords(Double dskUtilizWords) {
		this.dskUtilizWords = dskUtilizWords;
	}
	public Double getDskUtilizFrames() {
		return dskUtilizFrames;
	}
	public void setDskUtilizFrames(Double dskUtilizFrames) {
		this.dskUtilizFrames = dskUtilizFrames;
	}
	public Double getMemFrag() {
		return memFrag;
	}
	public void setMemFrag(Double memFrag) {
		this.memFrag = memFrag;
	}
	public Double getDskFrag() {
		return dskFrag;
	}
	public void setDskFrag(Double dskFrag) {
		this.dskFrag = dskFrag;
	}
	public Integer getIoClock() {
		return ioClock;
	}
	public void setIoClock(Integer ioClock) {
		this.ioClock = ioClock;
	}
	public Integer getPageFClock() {
		return pageFClock;
	}
	public void setPageFClock(Integer pageFClock) {
		this.pageFClock = pageFClock;
	}
	public Integer getSegFClock() {
		return segFClock;
	}
	public void setSegFClock(Integer segFClock) {
		this.segFClock = segFClock;
	}
	public Integer getPageFNum() {
		return pageFNum;
	}
	public void setPageFNum(Integer pageFNum) {
		this.pageFNum = pageFNum;
	}
	public List<String> getOut() {
		return out;
	}
	public Set<Integer> getFrameSet() {
		return frameSet;
	}
	public Set<Integer> getPageSet() {
		return pageSet;
	}
	public Integer getSegFNum() {
		return segFNum;
	}
	public void setSegFNum(Integer segFNum) {
		this.segFNum = segFNum;
	}
	
	
	
	

}
