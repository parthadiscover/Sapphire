/**
 *  Name : Ipsita Ghosh
 *  
 *  Course Number : CS 5323
 *  
 *  Assignment Title : A Simple Batch System ( Phase 2)
 *  
 *  Date : 04/03/2918
 *  
 *  Description of Global Variable :
 *  in - USER Input 
 *  clock - calculating the clock time 
 *  out - Output in console
 *  IOClock - calculating the IO Clock time
 *  tempclock - calculating interval time for printing pmt for every 15 clock
 *  disclock - giving disc location
 * Reading the input loader format
 * For IO additional clock is 15
 * printing in output file
 * SYSTEM sending data to DISC in binary format
 * 
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class SYSTEM {
	
	private static final Integer JOB_BATCH_SIZE = DISC.SIZE;    // to be un-commented before submission
//	private static final Integer JOB_BATCH_SIZE = 1048;    // to be commented before submission
	private static Integer jobLoadCounter = 0;
	private static Integer lastLoadedJobId = -1;
	private static Boolean allLoadedFlag = false;
	private static List<Integer> out = new ArrayList<Integer>();
	public static int clock = 0;
	public static int tempclock = 0;
	private static int lastclock = 0;
	public static PrintStream console = System.out;
	public static PrintStream outfile ;
	public static int IOClock = 0;
	public static String[] param;
	public static int discLoc = 0;
	public static List<String> pageSnapshot = new ArrayList<String>();
	public static List<Integer> debug = new ArrayList<Integer>();  //for debug
	
	public static void main(String[] args){
		
		param = args;
		console = System.out;
		enableOutput();
		
		try{
			
		
				File f = new File("trace_file.txt");
				if (f.exists()) {
					f.delete();
				}
		//		System.setOut(new PrintStream(new ByteArrayOutputStream()));
				

	//		LOADER.init();
			SYSTEM.execute(loadLoaderFormat());
	//		CPU.init();
	//		CPU.schedule();
			
			
			
			
			
			
	//		CPU.cpuProc(MEMORY.initialPc);

			System.out.println("===============================END EXECUTION===============================");
			
			
			
			
			System.out.println("===============================OUTPUT===============================");
			
			out.stream().map(BASE_CPU::decToHex).forEach(System.out::println);
			
			System.out.println("Input Pos  : "+PCB.getInstance(lastLoadedJobId).getInputDskStartPos()+"  "+PCB.getInstance(lastLoadedJobId).getInputDskEndPos());

//			System.out.println("INPUT : "+new String(BASE_CPU.decToBin(out.get(0))));
//			System.out.println("RESULT : "+new String(BASE_CPU.decToBin(out.get(1))) +"  "+BASE_CPU.decToHex(out.get(1)));
//			System.out.println("CLOCL in vtu  : "+BASE_CPU.decToHex(clock));
//			
//			int val1 = (8-(DISC.counter%8)) + DISC.counter;
//			String Input = MEMORY.memoryProc(0, val1, null);
//			
//			
//			int val = (8-(DISC.counter%8)) + DISC.counter +8;
//			String Output1 = MEMORY.memoryProc(0, val, null);
//			String Output2 = MEMORY.memoryProc(0, val+1, null);
			
			changeToOutput();
				System.out.println("===============================OUTPUT===============================");
				
				
				
				
//				System.out.println("JOB ID (Bin) : " + MEMORY.jobId);
		
				
//				System.out.println("INPUT (Bin) : "+Input + " ,  JOB ID  : "+MEMORY.jobId);
				
//				System.out.println("OUTPUT (Bin) : "+Output1 + " ,  JOB ID  : "+MEMORY.jobId);
				
//				System.out.println("             : "+Output2  +" ,  JOB ID  : "+MEMORY.jobId);
//				System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
//				System.out.println("IO Time  (Dec) :" + IOClock);
//				System.out.println("Execution Time (Dec) :" + (clock - IOClock));
//				System.out.println("PAGE FAULT  Time (Dec) : " + PAGEFAULT_HANDLER.PF_CLOCK);
//				System.out.println("SEGMENT FAULT  Time (Dec) :" + SEGMENT_FAULT.SF_CLOCK);
//				MEMORY.printMemoryUtilz();
//				DISC.printDskUtilization();
//				MEMORY.printMemFragmentation();
//				DISC.printDskFragment();
//				
				
				//Have to modify trace
//				if(MEMORY.trace == 1){
//					enableTrace();
//					System.out.println("**************************************TRACE OUTPUT (in HEX)****************************************");
//					System.out.println(" PC     BR   IR   TOS_BF  S[TOS]_BF  EA_BF   (EA)_BF    TOS_AF  S[TOS]_AF    EA_AF   (EA)_AF	 ");
//					System.out.println();
//					TRACE.getTraceList().stream().forEach(System.out :: println);
//				}
//				changeToOutput();
				System.out.println("NORMAL TERMINATION .");
				
		}catch(Exception e){
			e.printStackTrace();
		
			if(e.getMessage().contains("ERROR") || e.getMessage().contains("WARNING")){
			
				System.out.println(e.getMessage());
				changeToOutput();
				System.out.println("JOB ID (Bin) : " + 1);
				System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
				System.out.println(e.getMessage());
			}
			else{
				ERROR_HANDLER.handle(0);
			}
			changeToOutput();
			System.out.println("ABNORMAL TERMINATION .");
		}
		
		printPageSnapsAtClckIntr();
	}
	
	public static void execute(Supplier<Stream<String>> streamSupplier){
		
		
	//		load(streamSupplier);
			
			
			while(!allLoadedFlag){
				discLoc = 0;
				LOADER.init();
				loadEach(streamSupplier);
				CPU.init();
				CPU.schedule();				
//				out.stream().map(BASE_CPU::decToHex).forEach(System.out::println);
				System.out.println("Last Job : "+lastLoadedJobId);
				System.out.println("Batch Complete");
			}
	
//			for (Entry<Integer, PCB> entry : PCB.pcbMapper.entrySet()) {
//				
//				PCB pcb = entry.getValue();
//		        System.out.println("======================"+entry.getKey()+"====================");
//		        System.out.println("PRG START POS :: "+pcb.getPrgmDskStartPos());
//		        System.out.println("PRG END POS :: "+pcb.getPrgmDskEndPos());
//		        System.out.println("INP START POS :: "+pcb.getInputDskStartPos());
//		        System.out.println("INP END POS :: "+pcb.getInputDskEndPos());
//		        System.out.println("OUT START POS :: "+pcb.getOutputDskStartPos());
//		        System.out.println("OUT START POS :: "+pcb.getOutputDskEndPos());
//		        System.out.println("=============================================================");
//		    }
			
			
			for(Integer i : debug){
				PCB pcb = PCB.getInstance(i);
				System.out.println("======================"+i+"====================");
		        System.out.println("PRG START POS :: "+pcb.getPrgmDskStartPos());
		        System.out.println("PRG END POS :: "+pcb.getPrgmDskEndPos());
		        System.out.println("INP START POS :: "+pcb.getInputDskStartPos());
		        System.out.println("INP END POS :: "+pcb.getInputDskEndPos());
		        System.out.println("OUT START POS :: "+pcb.getOutputDskStartPos());
		        System.out.println("OUT START POS :: "+pcb.getOutputDskEndPos());
		        System.out.println("RELATIVE PC :: "+pcb.getInitialProgramCounter());
		        System.out.println("ABSOLUTE PC :: "+pcb.getProgramCounter());
		        System.out.println("=============================================================");
				
			}
			System.out.println("DB SZ : "+debug.size());
			System.out.println("READY QUEUE SZ : "+LOADER.readyQueue.size());
			
		//	CPU.cpuProc(MEMORY.initialPc, MEMORY.trace);
			
		
	}
	
	public static void writeio(Integer val){
		out.add(val);
		clock = clock +15;
		SYSTEM.logClock();
	}
	
	
	//****** Reading the input loader format to DISC*****//
	public static Supplier<Stream<String>> loadLoaderFormat(){
		Supplier<Stream<String>> streamSupplier = () -> {
			try {
			
				return Files.lines(Paths.get(ClassLoader.getSystemResource("finput2.txt").toURI()));
			} catch (IOException | URISyntaxException e) {
				e.printStackTrace();
			}
			return null;
		};
		
		return streamSupplier;
	}
	
	//****** writing the output in output file ****//
	
	public static void enableOutput(){	
		try {
			outfile = (new PrintStream(new FileOutputStream("output.txt")));
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		}
	}
	
	public static void changeToOutput(){	
		System.setOut(outfile);
	}
	public static void changeToConsole(){	
		System.setOut(console);
	}
	
	public static void enableTrace(){
		
		try {
			System.setOut(new PrintStream(new FileOutputStream("trace_file.txt")));
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		}
	}
	
	
	
	//************* Adding data to DISC ***********//

	public static void load(Supplier<Stream<String>> streamSupplier){
		
		while(!allLoadedFlag){
		loadEach(streamSupplier);
		System.out.println("Batch Complete");
		}
		
		
		
//		LOADER.initvar();
		
///		vaidateJob(streamSupplier);
		
		
//		String jobDetails =  streamSupplier.get()
//										.skip(1)  // exclude **JOB 06 02
//										.findFirst()
//										.get();
//		MEMORY.addJobParams(jobDetails);
//		PCB.getInstance(CPU.currentJob).setJobId(MEMORY.jobId);
		
		
//		addToDisc(streamSupplier);
		
	}
	
	
	
	
	
	private static void loadEach(Supplier<Stream<String>> streamSupplier){
		
		
		Integer  accumlSize = 0;
		boolean  loadFlag = false;
		boolean  jStart = false;
		boolean  prgStart = false;
		boolean  inStart = false;
		PCB pcb = null;
		
		Iterator<String> it = streamSupplier.get().iterator();
		int bckDskLoc = discLoc;
		
		 while(it.hasNext()) {
			 String line = it.next();
			 System.out.println("DSKLOC : "+discLoc);
		 try{
			 
			 if(line.startsWith("**JOB")){
				 
				 if(jStart){
					 			// reset disk locat
					 try{
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER120,Integer.toString(lastLoadedJobId));
					 }catch(Exception e){
						 	discLoc = pcb.getProgramCounter() -  pcb.getInitialProgramCounter() ; 
							System.out.println(e.getMessage());
							System.out.println("JOB ID (Bin) : " + pcb.getJobId());
					 }
				 }
				 
				 

				 	pcb = addJobParams(line,it.next());
				 	System.out.println("JJID ::"+pcb.getJobId());
				 	
				 	
				 	//// Only Load the Next Batched Job
				 	  if(lastLoadedJobId == pcb.getJobId() && lastLoadedJobId != -1 && !loadFlag){    // && lastLoadedJobId != -1   means skip for start job
				 		 loadFlag=true;
				 		 continue;
				 	  }else if(!loadFlag && lastLoadedJobId != -1){
				 		  continue;
				 	  }else{
				 		 loadFlag=true;
				 		 accumlSize = accumlSize + calculateSize(pcb.getJobSize()) + calculateSize(pcb.getInputSize()) + calculateSize(pcb.getOutputSize()) ;       
				 		 if(accumlSize > SYSTEM.JOB_BATCH_SIZE){
				 			 return;
				 		 }
				 		  
				 	  }
				 	
				 	////
				 	lastLoadedJobId = pcb.getJobId();  // extract job params and set to PCB
				 	pcb.setProgramCounter(pcb.getInitialProgramCounter()+discLoc);  // Set Program counter with job offset
				 	bckDskLoc = discLoc;
				 	
				 	jStart = true;
				 	prgStart = true;
				 	pcb.setPrgmDskStartPos(discLoc);
				 	System.out.println("Inside Job ");
				 	debug.add(pcb.getJobId());
				 	
				 	continue;
				}
			 else if(line.startsWith("**INPUT") && prgStart){
				 	prgStart = false;
				 	inStart = true;
				 	discLoc = discLoc +(8 - (discLoc%8));
				 	pcb.setInputDskStartPos(discLoc);
				 	System.out.println("Inside Input");
				 	continue;
			 }
			 else if(line.startsWith("**FIN") && jStart){
				 
				 //validate
				 
				 if(!jStart){
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER113);
				 }else if(jStart && !inStart){
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER114);
				 }
				 
				 	jStart = false;
				 	prgStart = false;
				 	inStart = false;
				 	pcb.setInputCounter(pcb.getInputDskStartPos());    // initializing the input counter with first input location
				 	
				 	
				 	discLoc = discLoc + (8 - (discLoc%8));				// point to next page
				 	pcb.setOutputCounter(discLoc);
				 	pcb.setOutputDskStartPos(discLoc);
				 	discLoc = discLoc + pcb.getOutputSize() -1;        // move to output disk loc
				 	pcb.setOutputDskEndPos(discLoc);
				 	discLoc = discLoc + (8 - (discLoc%8))  ;			//again point to next page for next job
				 	
				 	
				 	LOADER.readyQueue.add(pcb.getJobId());				// Add Job to Ready Queue
				 	jobLoadCounter++;
					System.out.println("Inside Finish :: "+ jobLoadCounter);
			 }
			 
			 
			 if(jStart && prgStart){
				 System.out.println("Line "+discLoc);				 
				 addWordsToDisc(line);
				 pcb.setPrgmDskEndPos(discLoc);         // constantly updates the program end disk position
				 
			 }else if(jStart && inStart && !prgStart){				 
				 addInputToDisc(line);
				 pcb.setInputDskEndPos(discLoc);         // constantly updates the input end disk position
			 }
			 
			 }catch(Exception e){
				 discLoc = pcb.getProgramCounter() -  pcb.getInitialProgramCounter() ;  			// reset disk locat
				 if(e.getMessage().contains("ERROR") || e.getMessage().contains("WARNING")){
						
						System.out.println(e.getMessage());
						System.out.println("JOB ID (Bin) : " + pcb.getJobId());
						System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
					}
					else{
						System.out.println("ERROR LOADING JOB " +pcb.getJobId()+"  Skipping....");
					}
			 }
		}
		
		allLoadedFlag = true;
		
	}
	
	
	
	
	
	private static void addInputToDisc(String line){
			
		
		if(! line.matches("^[0-9A-F/-]+$")){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER119);
		}
		
		if(line.length() % 4 != 0){
			ERROR_HANDLER.handle(ERROR_HANDLER.WR204);
		}
		else{			
			for(int i=0;i<line.length();i=i+4){
				String word = line.substring(i,i+4);
				DISC.addToDisk(hexToBinary(word), discLoc);
				discLoc++;
			}
		}
		
		
	}
	
	
	private static void addWordsToDisc(String line){
				if(line.length()!=16){					
					ERROR_HANDLER.handle(ERROR_HANDLER.WR203);
					line = (line + "0000000000000000");
					line = line.substring(0,16);
				}
				for(int i=0;i<16;i=i+4){
					String word = line.substring(i,i+4);
					DISC.addToDisk(hexToBinary(word), discLoc);
					discLoc++;
				}
	}
	


	
	private static String hexToBinary(String hex) {
	    int i = Integer.parseInt(hex, 16);
	    String bin = Integer.toBinaryString(i);
	    return bin;
	}
	
	private static void printPageSnapsAtClckIntr(){
	
		pageSnapshot.stream().forEach(System.out::println);
	
	}
	
	
	//********* Clock interval for printing PMT *********//
	
	public static void logClock(){
		if((clock - lastclock) >= 15){
			StringBuilder snap =  new StringBuilder();
			tempclock= tempclock + 15;
			snap.append("At Clock Value  "+ tempclock  +" :: ");
			for(int i=0;i<32 ;i++){
////				int page = PCB.pageFrameTableCollect[0][i][0];
//				if(page != -1){
//					snap.append("Frame: "+i+" --> Page: "+page+ " , ");
//				}
			}				
			pageSnapshot.add(snap.toString());
			snap.setLength(0);
			lastclock = clock;
		}				
}
	
	
private static PCB addJobParams(String jobLine , String hex){
	
	PCB pcb = null;
	
	
	String[] jbArr = hex.split("\\s+");
	if(jbArr.length != 5){
		ERROR_HANDLER.handle(ERROR_HANDLER.ER112);
	}
	
		try{
			
			System.out.println("JOB_ID :: "+ jbArr[0]);
			System.out.println("LOAD ADDR :: " +jbArr[1]);
			System.out.println("INITIAL_PC :: "+jbArr[2]);
			System.out.println("SIZE :: "+jbArr[3]);
			System.out.println("TRACE FLAG :: "+jbArr[4]);
		}catch(Exception e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER112);
		}
		
		
		if((!jbArr[4].substring(0, 1).trim().equals("0")) || (!jbArr[4].substring(0, 1).trim().equals("1"))){
			ERROR_HANDLER.handle(ERROR_HANDLER.WR202);
		}	
		
		try{
			Integer jobId =  Integer.parseInt(jbArr[0], 16);
			pcb = PCB.getInstance(jobId);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER107);
		}
		
		try{
			Integer loadAddr =  Integer.parseInt(jbArr[1], 16);
			pcb.setLoadAddrs(loadAddr);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER108);
		}
		
		try{
			Integer initialPc = Integer.parseInt(jbArr[2], 16);
			System.out.println(":INPC : "+initialPc);
			pcb.setInitialProgramCounter(initialPc);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER109);
		}
		
		try{
			Integer size =  Integer.parseInt(jbArr[3], 16);
			pcb.setJobSize(size);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER110);
		}

			
		Integer trace =  Integer.parseInt(jbArr[4], 16);
		pcb.setTrace(trace);
		
		
		String[] ioArr = jobLine.split("\\s+");
		if(ioArr.length == 3 && ioArr[0].startsWith("**JOB")){
			pcb.setInputSize(Integer.parseInt(ioArr[1],16));
			pcb.setOutputSize(Integer.parseInt(ioArr[2],16));
		}else{
			//error
		}
		
		
		return pcb ;
	}

	private static int calculateSize(int pos){
		return pos + (8 - (pos % 8));
	}

}



