/*
 * DISC class getting data from SYSTEM.
 * Storing each word in each location.
 * Size of the DISC size is 8 times of memory.
 * DISC used as virtual memory.
 * 
 */
import java.util.Arrays;

public class DISC {
	
	public static final int SIZE = 2047;  //0-2047
	private static  char disk[][] = new char[2048][16];
	
	// create segment table while adding to disk
	public static int counter = -1;
	
	
	public static void addToDisk(String bin,int pos){	
		String pad = "0000000000000000" + bin;         // padding
		bin = pad.substring(pad.length()-16);					
		disk[pos] = bin.toCharArray();
		
	}
	
	
	public static char[] readFromDisk(int pos){
	
		return disk[pos];		
	}
	
	
	
	
	public static void printContent(){
		
		Arrays.stream(disk)
		.map(n->new String(n))
		.forEach( n -> System.out.println(n));
	}
	
	//**************** Disc Utilization ************//
	public static void dskUtilization(){
		
		Integer totJbSize = CPU.currentPCB.getJobSize() + CPU.currentPCB.getInputSize() + CPU.currentPCB.getOutputSize();
		Integer totPgSize = getPagesUsed(CPU.currentPCB.getJobSize())+getPagesUsed(CPU.currentPCB.getInputSize())+getPagesUsed(CPU.currentPCB.getOutputSize());
		double dskUtilWr = (double)totJbSize/(SIZE+1);
		double dskUtilFr = (double)totPgSize/((SIZE+1)/8);
		CPU.currentPCB.getOutput().setDskUtilizWords(dskUtilWr);
		CPU.currentPCB.getOutput().setDskUtilizFrames(dskUtilFr);
		System.out.println("DISC UTILIZATION WORDS --  Ratio :"+ dskUtilWr + "  Percentage :"+(dskUtilWr *100) +"%");
		System.out.println("DISC UTILIZATION FRAMES --  Ratio :"+ dskUtilFr + "  Percentage :"+(dskUtilFr *100) +"%");
		
	}
	
	//************ Disc Fragmentation ***********//
	
	public static void dskFragmentation(){
		
		int unusedWords = getUnUsedWords(CPU.currentPCB.getJobSize()) + getUnUsedWords(CPU.currentPCB.getInputSize()) + getUnUsedWords(CPU.currentPCB.getOutputSize());
		double avgUnusedWrds = (double)unusedWords / 3 ;
		CPU.currentPCB.getOutput().setDskFrag(avgUnusedWrds);
		System.out.println("DISC FRAGMENTATION : "+avgUnusedWrds);
	}

	private static int getPagesUsed(int size){
		return (size/8) + (size % 8 == 0 ? 0 : 1);
	}
	private static int getUnUsedWords(int size){
		return (8 - (size % 8));
	}
}
