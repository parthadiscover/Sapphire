/**
 *  Name : Ipsita Ghosh
 *  
 *  Course Number : CS 5323
 *  
 *  Assignment Title : A Simple Batch System ( Phase 2)
 *  
 *  Date : 04/03/2918
 *  
 *  Description of Global Variable :
 *  in - USER Input 
 *  clock - calculating the clock time 
 *  out - Output in console
 *  IOClock - calculating the IO Clock time
 *  tempclock - calculating interval time for printing pmt for every 15 clock
 *  disclock - giving disc location
 * Reading the input loader format
 * For IO additional clock is 15
 * printing in output file
 * SYSTEM sending data to DISC in binary format
 * 
 */
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SYSTEM {
	
	private static final Integer JOB_BATCH_SIZE = DISC.SIZE;    // to be un-commented before submission
//	private static final Integer JOB_BATCH_SIZE = 1048;    // to be commented before submission
	private static Integer jobLoadCounter = 1;
	private static Integer lastLoadedJobId = -1;
	private static Integer batchSize = 0;
	private static Boolean allLoadedFlag = false;
	private static List<Integer> out = new ArrayList<Integer>();
	public static int clock = 0;
	public static int tempclock = 0;
	private static int lastclock = 0;
	public static PrintStream console = System.out;
	public static PrintStream outfile ;
	public static int IOClock = 0;
	public static String[] param;
	public static int discLoc = 0;
	public static List<String> pageSnapshot = new ArrayList<String>();
	public static List<Integer> debug = new ArrayList<Integer>();  //for debug
	public static List<Integer> completed = new ArrayList<Integer>();
	public static List<Integer> batchSizeList = new ArrayList<Integer>();
	
	public static void main(String[] args){
		
		param = args;
		console = System.out;
		
		try{
			
				changeToBlankStream();
				cleanFiles();
				CPU.init();
				SYSTEM.execute(loadLoaderFormat());
				printOutput();
			
			
			

//			System.out.println("===============================END EXECUTION===============================");
			
			
			
			
//			System.out.println("===============================OUTPUT===============================");
			
//			out.stream().map(BASE_CPU::decToHex).forEach(System.out::println);
			
//			System.out.println("Input Pos  : "+PCB.getInstance(lastLoadedJobId).getInputDskStartPos()+"  "+PCB.getInstance(lastLoadedJobId).getInputDskEndPos());

//			System.out.println("INPUT : "+new String(BASE_CPU.decToBin(out.get(0))));
//			System.out.println("RESULT : "+new String(BASE_CPU.decToBin(out.get(1))) +"  "+BASE_CPU.decToHex(out.get(1)));
//			System.out.println("CLOCL in vtu  : "+BASE_CPU.decToHex(clock));
//			
//			int val1 = (8-(DISC.counter%8)) + DISC.counter;
//			String Input = MEMORY.memoryProc(0, val1, null);
//			
//			
//			int val = (8-(DISC.counter%8)) + DISC.counter +8;
//			String Output1 = MEMORY.memoryProc(0, val, null);
//			String Output2 = MEMORY.memoryProc(0, val+1, null);
			
//			changeToOutput();
//				System.out.println("===============================OUTPUT===============================");
				
				
				
				
//				System.out.println("JOB ID (Bin) : " + MEMORY.jobId);
		
				
//				System.out.println("INPUT (Bin) : "+Input + " ,  JOB ID  : "+MEMORY.jobId);
				
//				System.out.println("OUTPUT (Bin) : "+Output1 + " ,  JOB ID  : "+MEMORY.jobId);
				
//				System.out.println("             : "+Output2  +" ,  JOB ID  : "+MEMORY.jobId);
//				System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
//				System.out.println("IO Time  (Dec) :" + IOClock);
//				System.out.println("Execution Time (Dec) :" + (clock - IOClock));
//				System.out.println("PAGE FAULT  Time (Dec) : " + PAGEFAULT_HANDLER.PF_CLOCK);
//				System.out.println("SEGMENT FAULT  Time (Dec) :" + SEGMENT_FAULT.SF_CLOCK);
//				MEMORY.printMemoryUtilz();
//				DISC.printDskUtilization();
//				MEMORY.printMemFragmentation();
//				DISC.printDskFragment();
//				
				
				//Have to modify trace
//				if(MEMORY.trace == 1){
//					enableTrace();
//					System.out.println("**************************************TRACE OUTPUT (in HEX)****************************************");
//					System.out.println(" PC     BR   IR   TOS_BF  S[TOS]_BF  EA_BF   (EA)_BF    TOS_AF  S[TOS]_AF    EA_AF   (EA)_AF	 ");
//					System.out.println();
//					TRACE.getTraceList().stream().forEach(System.out :: println);
//				}
//				changeToOutput();
				
		}catch(Exception e){
			System.out.println("EEEEE : "+e.getMessage());
			e.printStackTrace();
		
			if(e.getMessage().contains("ERROR") ){
				
				System.out.println(e.getMessage());
				changeToOutput();
				System.out.println("JOB ID (Bin) : " + 1);
				System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
				System.out.println(e.getMessage());
			}
			else{
				ERROR_HANDLER.handle(0);
			}
			changeToOutput();
			System.out.println("ABNORMAL TERMINATION .");
		}
		
		printPageSnapsAtClckIntr();
	}
	
	public static void execute(Supplier<Stream<String>> streamSupplier){
		
		
	//		load(streamSupplier);
			
			
			while(!allLoadedFlag){
				discLoc = 0;
				jobLoadCounter = 1;
				batchSize = 0;
				LOADER.init();
				loadEach(streamSupplier);				
				CPU.schedule();	
				batchSizeList.add(batchSize.intValue());
				out.stream().map(BASE_CPU::decToHex).forEach(System.out::println);
				System.out.println("Last Job : "+lastLoadedJobId);
				System.out.println("Batch Complete");
			}
	
//			for (Entry<Integer, PCB> entry : PCB.pcbMapper.entrySet()) {
//				
//				PCB pcb = entry.getValue();
//		        System.out.println("======================"+entry.getKey()+"====================");
//		        System.out.println("PRG START POS :: "+pcb.getInpDskStartPos());
//		        System.out.println("PRG END POS :: "+pcb.getPrgmDskEndPos());
//		        System.out.println("INP START POS :: "+pcb.getInputDskStartPos());
//		        System.out.println("INP END POS :: "+pcb.getInputDskEndPos());
//		        System.out.println("OUT START POS :: "+pcb.getOutputDskStartPos());
//		        System.out.println("OUT START POS :: "+pcb.getOutputDskEndPos());
//		        System.out.println("=============================================================");
//		    }
			
			
//			for(Integer i : debug){
//				PCB pcb = PCB.getInstance(i);
//				System.out.println("======================"+i+"====================");
//		        System.out.println("PRG START POS :: "+pcb.getPrgmDskStartPos());
//		        System.out.println("PRG END POS :: "+pcb.getPrgmDskEndPos());
//		        System.out.println("INP START POS :: "+pcb.getInputDskStartPos());
//		        System.out.println("INP END POS :: "+pcb.getInputDskEndPos());
//		        System.out.println("OUT START POS :: "+pcb.getOutputDskStartPos());
//		        System.out.println("OUT START POS :: "+pcb.getOutputDskEndPos());
//		        System.out.println("RELATIVE PC :: "+pcb.getInitialProgramCounter());
//		        System.out.println("ABSOLUTE PC :: "+pcb.getProgramCounter());
//		        System.out.println("=============================================================");
//				
//			}
			System.out.println("DB SZ : "+debug.size());
			System.out.println("READY QUEUE SZ : "+LOADER.readyQueue.size());
			
		//	CPU.cpuProc(MEMORY.initialPc, MEMORY.trace);
			
		
	}
	
	public static void writeio(Integer val){
		out.add(val);
		clock = clock +15;
		SYSTEM.logClock();
	}
	
	
	//****** Reading the input loader format to DISC*****//
	public static Supplier<Stream<String>> loadLoaderFormat(){
		Supplier<Stream<String>> streamSupplier = () -> {
			try {
		//		return Files.lines(Paths.get(ClassLoader.getSystemResource("finput2.txt").toURI()));
				return Files.lines(Paths.get(ClassLoader.getSystemResource("errorfile01.txt").toURI()));
			} catch (IOException | URISyntaxException e) {
				e.printStackTrace();
			}
			return null;
		};
		
		return streamSupplier;
	}
	
	//****** writing the output in output file ****//
	
	public static void enableOutput(){	
		try {
			outfile = (new PrintStream(new FileOutputStream("output.txt")));
			changeToOutput();
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		}
	}
	
	public static void changeToOutput(){	
		System.setOut(outfile);
	}
	public static void changeToConsole(){	
		System.setOut(console);
	}
	public static void changeToBlankStream(){	
//		System.setOut(new PrintStream(new ByteArrayOutputStream()));    // will disable console printout
	}
	
	public static void printTrace(PCB pcb){
		
		try {
			System.setOut(new PrintStream(new FileOutputStream("trace_file_"+pcb.getJobId()+".txt")));
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		}
			System.out.println("**************************************TRACE OUTPUT (in HEX)*** JOB_ID:"+pcb.getJobId()+" *************************************");
			System.out.println(" PC     BR   IR   TOS_BF  S[TOS]_BF  EA_BF   (EA)_BF    TOS_AF  S[TOS]_AF    EA_AF   (EA)_AF	 ");
			System.out.println();
			pcb.getOutput().getTraceList().stream().forEach(System.out :: println);
			changeToOutput();
	}
	
	
	
	//************* Adding data to DISC ***********//

private static void loadEach(Supplier<Stream<String>> streamSupplier){
		
		
		Integer  accumlSize = 0;
		boolean  loadFlag = false;
		boolean  jStart = false;
		boolean  prgStart = false;
		boolean  inStart = false;
		PCB pcb = null;
		
		Iterator<String> it = streamSupplier.get().iterator();
		int bckDskLoc = discLoc;
		
		 while(it.hasNext()) {
			 String line = it.next();
		//	 System.out.println("DSKLOC : "+discLoc);
		 try{
			 
			 if(line.startsWith("**JOB")){
				 
				 if(jStart){
					 			// reset disk locat
					 try{
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER120,Integer.toString(lastLoadedJobId));
					 }catch(Exception e){
						 if(pcb.getProgramCounter()!=null){
						 	discLoc = pcb.getProgramCounter() -  pcb.getInitialProgramCounter() ; 
						 }
							System.out.println(e.getMessage());
							System.out.println("JOB ID (Bin) : " + pcb.getJobId());
					 }
				 }
				 
				 

				 	pcb = addJobParams(line,it.next(),jobLoadCounter);
				 	System.out.println("JJID ::"+pcb.getJobId());
				 	
				 	
				 	//// Only Load the Next Batched Job
				 	  if(lastLoadedJobId == pcb.getJobId() && lastLoadedJobId != -1 && !loadFlag){    // && lastLoadedJobId != -1   means skip for start job
				 		 loadFlag=true;
				 		jobLoadCounter++;
				 		 continue;
				 	  }else if(!loadFlag && lastLoadedJobId != -1){
				 		 jobLoadCounter++;
				 		  continue;
				 	  }else{
				 		 loadFlag=true;
				 		 accumlSize = accumlSize + calculateSize(pcb.getJobSize()) + calculateSize(pcb.getInputSize()) + calculateSize(pcb.getOutputSize()) ;       
				 		 if(accumlSize > SYSTEM.JOB_BATCH_SIZE){
				 			 return;
				 		 }
				 		  
				 	  }
				 	
				 	////
				 	lastLoadedJobId = pcb.getJobId();  // extract job params and set to PCB
				 	pcb.setProgramCounter(pcb.getInitialProgramCounter()+discLoc);  // Set Program counter with job offset
				 	bckDskLoc = discLoc;
				 	
				 	jStart = true;
				 	prgStart = true;
				 	pcb.setPrgmDskStartPos(discLoc);
				 	System.out.println("Inside Job ");
				 	debug.add(pcb.getJobId());
				 	
				 	continue;
				}
			 else if(line.startsWith("**INPUT") && prgStart){
				 	prgStart = false;
				 	inStart = true;
				 	discLoc = discLoc +(8 - (discLoc%8));
				 	pcb.setInputDskStartPos(discLoc);
				 	System.out.println("Inside Input");
				 	continue;
			 }
			 else if(line.startsWith("**FIN") && jStart){
				 
				 //validate
				 
				 if(!jStart){
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER113);
				 }else if(jStart && !inStart){
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER114);
				 }
				 
				 	jStart = false;
				 	prgStart = false;
				 	inStart = false;
				 	pcb.setInputCounter(pcb.getInputDskStartPos());    // initializing the input counter with first input location
				 	
				 	
				 	discLoc = discLoc + (8 - (discLoc%8));				// point to next page
				 	pcb.setOutputCounter(discLoc);
				 	pcb.setOutputDskStartPos(discLoc);
				 	discLoc = discLoc + pcb.getOutputSize() -1;        // move to output disk loc
				 	pcb.setOutputDskEndPos(discLoc);
				 	discLoc = discLoc + (8 - (discLoc%8))  ;			//again point to next page for next job
				 	
				 	
				 	LOADER.readyQueue.add(pcb.getJobId());				// Add Job to Ready Queue
				 	jobLoadCounter++;
				 	batchSize++;
					System.out.println("Inside Finish :: "+ jobLoadCounter);
			 }
			 
			 
			 if(jStart && prgStart){
				 System.out.println("Line "+discLoc);				 
				 addWordsToDisc(line);
				 pcb.setPrgmDskEndPos(discLoc);         // constantly updates the program end disk position
				 
			 }else if(jStart && inStart && !prgStart){				 
				 addInputToDisc(line);
				 pcb.setInputDskEndPos(discLoc);         // constantly updates the input end disk position
			 }
			 
			 }catch(Exception e){
				 if(pcb.getProgramCounter()!=null){
					 discLoc = pcb.getProgramCounter() -  pcb.getInitialProgramCounter() ;  			// reset disk locat
				 }
					 if(e.getMessage() != null && e.getMessage().contains("ERROR")){
						
						System.out.println(e.getMessage());
						PCB.getInstance(0).getOutput().getOutSb().append("ERROR LOADING JOB " +pcb.getJobId()+"  Skipping....").append(System.getProperty("line.separator"));
						System.out.println("JOB ID (Bin) : " + pcb.getJobId());
						System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
					}
					else{
						System.out.println("ERROR LOADING JOB " +pcb.getJobId()+"  Skipping....");
						PCB.getInstance(0).getOutput().getOutSb().append("ERROR LOADING JOB " +pcb.getJobId()+"  Skipping....").append(System.getProperty("line.separator"));
					}
			 }
		}
		
		allLoadedFlag = true;
		
	}
	
	
	
	
	private static void addInputToDisc(String line){
			
		
		if(! line.matches("^[0-9A-F/-]+$")){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER119);
		}
		
		if(line.length() % 4 != 0){
			ERROR_HANDLER.handle(ERROR_HANDLER.WR204);
		}
		else{			
			for(int i=0;i<line.length();i=i+4){
				String word = line.substring(i,i+4);
				DISC.addToDisk(hexToBinary(word), discLoc);
				discLoc++;
			}
		}
		
		
	}
	
	
	private static void addWordsToDisc(String line){
				if(line.length()!=16){					
					ERROR_HANDLER.handle(ERROR_HANDLER.WR203,jobLoadCounter.toString());
					line = (line + "0000000000000000");
					line = line.substring(0,16);
				}
				for(int i=0;i<16;i=i+4){
					String word = line.substring(i,i+4);
					DISC.addToDisk(hexToBinary(word), discLoc);
					discLoc++;
				}
	}
	


	
	private static String hexToBinary(String hex) {
	    int i = Integer.parseInt(hex, 16);
	    String bin = Integer.toBinaryString(i);
	    return bin;
	}
	
	private static void printPageSnapsAtClckIntr(){
		pageSnapshot.stream().forEach(System.out::println); 
	
	}
	  
	
	//********* Clock interval for printing PMT *********//
	
	public static void logClock(){
		if((clock - lastclock) >= 100){
			StringBuilder snap =  new StringBuilder();
			tempclock= tempclock + 100;
			snap.append(System.getProperty("line.separator"));
			snap.append("FRAME   -    PAGE  (Clock : "+tempclock+")");
			snap.append(System.getProperty("line.separator"));
			snap.append("-------------------");
			snap.append(System.getProperty("line.separator"));
			for(int i=0;i<32 ;i++){
				int page = PCB.pageFrameTable[i][0];
				if(page != -1){
					snap.append(i+"      -       "+page);
					snap.append(System.getProperty("line.separator"));
				}
			}				
			pageSnapshot.add(snap.toString());
			snap.setLength(0);
			lastclock = clock;
		}				
}
	
	
private static PCB addJobParams(String jobLine , String hex,Integer jobId){
	
	PCB pcb = null;
	
	
	String[] jbArr = hex.split("\\s+");
	if(jbArr.length != 5){
		ERROR_HANDLER.handle(ERROR_HANDLER.ER112);
	}
	
		try{
			
			System.out.println("JOB_ID :: "+ jobId);
			System.out.println("ORG JID :: "+ jbArr[0]);
			System.out.println("LOAD ADDR :: " +jbArr[1]);
			System.out.println("INITIAL_PC :: "+jbArr[2]);
			System.out.println("SIZE :: "+jbArr[3]);
			System.out.println("TRACE FLAG :: "+jbArr[4]);
		}catch(Exception e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER112);
		}
		
		
		if(!jbArr[4].matches("^[0-1/-]{1}+$")){
			System.out.println(jbArr[4].substring(0, 1).trim().equals("0"));
			ERROR_HANDLER.handle(ERROR_HANDLER.WR202);
		}	
		
		try{
			//Integer jobId =  Integer.parseInt(jbArr[0], 16);
			pcb = PCB.getInstance(jobId);
			pcb.setOriginaljobId(jbArr[0]);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER107);
		}
		
		try{
			Integer loadAddr =  Integer.parseInt(jbArr[1], 16);
			pcb.setLoadAddrs(loadAddr);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER108);
		}
		
		try{
			Integer initialPc = Integer.parseInt(jbArr[2], 16);
			System.out.println(":INPC : "+initialPc);
			pcb.setInitialProgramCounter(initialPc);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER109);
		}
		
		try{
			Integer size =  Integer.parseInt(jbArr[3], 16);
			pcb.setJobSize(size);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER110);
		}

			
		Integer trace =  Integer.parseInt(jbArr[4], 16);
		pcb.setTrace(trace);
		
		
		String[] ioArr = jobLine.split("\\s+");
		if(ioArr.length == 3 && ioArr[0].startsWith("**JOB")){
			pcb.setInputSize(Integer.parseInt(ioArr[1],16));
			pcb.setOutputSize(Integer.parseInt(ioArr[2],16));
		}else{
			//error
		}
		
		
		return pcb ;
	}

	private static int calculateSize(int pos){
		return pos + (8 - (pos % 8));
	}
	
	private static void cleanFiles() throws IOException{
		
		Path start = Paths.get("");
		int maxDepth = 1;
		try (Stream<Path> stream = Files.walk(start, maxDepth)) {
		    stream
		        .map(String::valueOf)
		        .filter(path -> (path.matches(".*trace_file.*\\.txt")  ||  path.matches(".*output.*\\.txt")))		        
		        .forEach(path -> new File(path).delete());
		}
			
	}
	
	private static void printOutput(){
		
		enableOutput();
		System.out.println("===============================OUTPUT===============================");
		
		
		if(PCB.getPcbMapper().containsKey(0)){
			System.out.println(PCB.getPcbMapper().get(0).getOutput().getOutSb().toString());
			PCB.getPcbMapper().remove(0);
		}
		
		
		System.out.print("Degree of MulProgrammimg of "+batchSizeList.size()+" batches are :: ");
		batchSizeList.forEach(n->{System.out.print(n +", ");});
		System.out.println();
	
		Double avgTurnArndTime = PCB.getPcbMapper().entrySet()
									  .stream()
									  .filter(n -> (n.getValue().getJobStartTime() !=0 && n.getValue().getJobEndTime() !=0))
									  .map(n-> n.getValue().getJobEndTime() - n.getValue().getJobStartTime())
									  .collect(Collectors.averagingDouble(n->(Double.valueOf(n))));
						  
		System.out.println("Average Turn Around Time : "+setPrecision(avgTurnArndTime));	
		
		OptionalLong minStartTime = PCB.getPcbMapper().entrySet()
				  .stream()
				  .filter(n -> (n.getValue().getJobStartTime() !=0 && n.getValue().getJobEndTime() !=0))
				  .map(n-> n.getValue().getJobEndTime() - n.getValue().getJobStartTime())
				  .mapToLong(n->n)
				  .min();
				  
	  
		System.out.println("Min Turnaround Time : "+minStartTime.getAsLong());			


		OptionalLong maxStartTime = PCB.getPcbMapper().entrySet()
				  .stream()
				  .filter(n -> (n.getValue().getJobStartTime() !=0 && n.getValue().getJobEndTime() !=0))
				  .map(n-> n.getValue().getJobEndTime() - n.getValue().getJobStartTime())
				  .mapToLong(n->n)
				  .max();
				  
	  
		System.out.println("Max Turnaround Time : "+maxStartTime.getAsLong());		
		
		
		//// PRG SEG METRC
		
		OptionalInt maxPrgmSize = PCB.getPcbMapper().entrySet()
				  					.stream()
				  					.map(n->n.getValue().getJobSize())
				  					.mapToInt(n->n)
				  					.max();
		
		System.out.println("Max Program Size : "+maxPrgmSize.getAsInt());	
		
		OptionalInt minPrgmSize = PCB.getPcbMapper().entrySet()
					.stream()
					.map(n->n.getValue().getJobSize())
					.mapToInt(n->n)
					.min();

		System.out.println("Min Program Size : "+minPrgmSize.getAsInt());	
		
		OptionalDouble avgPrgmSize = PCB.getPcbMapper().entrySet()
				.stream()
				.map(n->n.getValue().getJobSize())
				.mapToInt(n->n)
				.average();

		System.out.println("Average Program Size : "+setPrecision(avgPrgmSize.getAsDouble()));
	
	////INP SEG METRC
	
		OptionalInt maxInpSize = PCB.getPcbMapper().entrySet()
					.stream()
					.map(n->n.getValue().getInputSize())
					.mapToInt(n->n)
					.max();
	
		System.out.println("Max Input Size : "+maxInpSize.getAsInt());	
		
		OptionalInt minInpSize = PCB.getPcbMapper().entrySet()
		.stream()
		.map(n->n.getValue().getInputSize())
		.mapToInt(n->n)
		.min();
		
		System.out.println("Min Input Size : "+minInpSize.getAsInt());	
		
		OptionalDouble avgInpSize = PCB.getPcbMapper().entrySet()
		.stream()
		.map(n->n.getValue().getInputSize())
		.mapToInt(n->n)
		.average();

		System.out.println("Average Input Size : "+setPrecision(avgInpSize.getAsDouble()));
		
		
	////Out SEG METRC
		
			OptionalInt maxOutSize = PCB.getPcbMapper().entrySet()
						.stream()
						.map(n->n.getValue().getOutputSize())
						.mapToInt(n->n)
						.max();
		
			System.out.println("Max Output Size : "+maxOutSize.getAsInt());	
			
			OptionalInt minOutSize = PCB.getPcbMapper().entrySet()
			.stream()
			.map(n->n.getValue().getOutputSize())
			.mapToInt(n->n)
			.min();
			
			System.out.println("Min Output Size : "+minOutSize.getAsInt());	
			
			OptionalDouble avgOutSize = PCB.getPcbMapper().entrySet()
			.stream()
			.map(n->n.getValue().getOutputSize())
			.mapToInt(n->n)
			.average();

			System.out.println("Average Output Size : "+setPrecision(avgOutSize.getAsDouble()));
		
		
		//////////////////////////////////////////////////////////
		
		
		for (Integer jobCompleted : completed) {
			PCB pcb = PCB.getInstance(jobCompleted);
	        System.out.println("===========JOB ID : "+ jobCompleted +"=================") ;
			System.out.println("JOB ID (Bin) : " + pcb.getJobId());
			System.out.println(pcb.getOutput().getOutSb().toString());  /// print errors
			System.out.println("INPUT (Bin) : ");
			pcb.getOutput().getIn().forEach(n -> System.out.print(" 		"+n+" ,"));
			System.out.println();
			System.out.println("OUTPUT (Bin) : ");
			pcb.getOutput().getOut().forEach(n -> System.out.print(" 		"+n+" ,"));
			System.out.println();
			System.out.println("CLOCL value (Hex)  : "+pcb.getExecutedClockCycle());
			System.out.println("IO Time  (Dec) :" + pcb.getOutput().getIoClock());
			System.out.println("Execution Time (Dec) :" + (pcb.getExecutedClockCycle() - pcb.getOutput().getIoClock()));
			System.out.println("PAGE FAULT  Time (Dec) : " + pcb.getOutput().getPageFClock());
			System.out.println("PAGE FAULT  # (Dec) : " + pcb.getOutput().getPageFNum());
			System.out.println("SEGMENT FAULT  Time (Dec) : " + pcb.getOutput().getSegFClock());
			System.out.println("SEGMENT FAULT  # (Dec) : " + pcb.getOutput().getSegFNum());
			System.out.println("MEMORY UTILIZATION WORDS --  Ratio :"+  setPrecision(pcb.getOutput().getMemUtilizWords()) + "  Percentage :"+ setPrecision(pcb.getOutput().getMemUtilizWords()*100) +"%");
			System.out.println("MEMORY UTILIZATION FRAMES --  Ratio :"+  setPrecision(pcb.getOutput().getMemUtilizFrames()) + "  Percentage :"+ setPrecision(pcb.getOutput().getMemUtilizFrames() *100) +"%");
			System.out.println("DISK UTILIZATION WORDS --  Ratio :"+  setPrecision(pcb.getOutput().getDskUtilizWords()) + "  Percentage :"+ setPrecision(pcb.getOutput().getDskUtilizWords()*100) +"%");
			System.out.println("DISK UTILIZATION FRAMES --  Ratio :"+  setPrecision(pcb.getOutput().getDskUtilizFrames()) + "  Percentage :"+ setPrecision(pcb.getOutput().getDskUtilizFrames() *100) +"%");
			System.out.println("MEMORY FRAGMENTATION :: "+setPrecision(pcb.getOutput().getMemFrag()));
			System.out.println("DISK FRAGMENTATION :: "+setPrecision(pcb.getOutput().getDskFrag()));
			System.out.println("START TIME (DEC) :: "+pcb.getJobStartTime());
			System.out.println("END TIME (DEC) :: "+pcb.getJobEndTime());			
			System.out.println("TURN-AROUND TIME (DEC) :: "+(pcb.getJobEndTime() - pcb.getJobStartTime()));
			System.out.println(pcb.isNormalTermination()?"NORMAL TERMINATION ":"ABNORMAL TERMINATION");
			System.out.println();
			System.out.println("=================================================") ;
			
			
			/// If trace is enebled
			if(pcb.getTrace() == 1){
				printTrace(pcb);
			}
			
		}
		

	}
	
	private static String setPrecision(Double val){
		return new DecimalFormat("#0.00").format(val);
	}

}



