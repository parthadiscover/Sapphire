import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

 public class TRACE {
	
	
	private int jobId;
	private String pc;
	private String br;
	private String ir;
	private String tos_bef;
	private String tos_aft;
	private String s_tos_bef;
	private String s_tos_aft;
	private String ea_bef;
	private String ea_val_bef;
	private String ea_aft;
	private String ea_val_aft;
	
	public TRACE(int jobId){
		this.jobId = jobId;
	}
	
	public int getJobId() {
		return jobId;
	}

	public String getPc() {
		return pc;
	}
	public void setPc(String pc) {
		this.pc = pad(pc);
	}
	public String getBr() {
		return br;
	}
	public void setBr(String br) {
		this.br = pad(br);
	}
	public String getIr() {
		return ir;
	}
	public void setIr(String ir) {
		this.ir = pad(ir);
	}
	public String getTos_bef() {
		return tos_bef;
	}
	public void setTos_bef(String tos_bef) {
		this.tos_bef = pad(tos_bef);
	}
	public String getTos_aft() {
		return tos_aft;
	}
	public void setTos_aft(String tos_aft) {
		this.tos_aft = pad(tos_aft);
	}
	public String getS_tos_bef() {
		return s_tos_bef;
	}
	public void setS_tos_bef(String s_tos_bef) {
		this.s_tos_bef = pad(s_tos_bef);
	}
	public String getS_tos_aft() {
		return s_tos_aft;
	}
	public void setS_tos_aft(String s_tos_aft) {
		this.s_tos_aft = pad(s_tos_aft);
	}
	public String getEa_bef() {
		return ea_bef;
	}
	public void setEa_bef(String ea_bef) {
		this.ea_bef = pad(ea_bef);
	}
	public String getEa_val_bef() {
		return ea_val_bef;
	}
	public void setEa_val_bef(String ea_val_bef) {
		this.ea_val_bef = pad(ea_val_bef);
	}
	public String getEa_aft() {
		return ea_aft;
	}
	public void setEa_aft(String ea_aft) {
		this.ea_aft = pad(ea_aft);
	}
	public String getEa_val_aft() {
		return ea_val_aft;
	}
	public void setEa_val_aft(String ea_val_aft) {
		this.ea_val_aft = pad(ea_val_aft);
	}
	
	
		
	private static String pad (String s){
		return (s+"    ").substring(0, 4);
	}

	@Override
	public String toString() {
		return pc + "   " + br + "   " + ir + "     " + tos_bef + "    " + s_tos_bef + "     " + ea_bef 
				+ "     " + ea_val_bef + "      "+ tos_aft + "     " + s_tos_aft  + "     " + ea_aft  + "     " + ea_val_aft ;
	}

}
