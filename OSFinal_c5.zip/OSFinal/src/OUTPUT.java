import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OUTPUT {
	
	
	private List<String> out = new ArrayList<String>();
	private List<String> in = new ArrayList<String>();
	private Set<Integer> frameSet = new HashSet<Integer>();
	private Set<Integer> pageSet = new HashSet<Integer>();
	private Double memUtilizFrames=0.0d;
	private Double memUtilizWords=0.0d;
	private Double dskUtilizWords=0.0d;
	private Double dskUtilizFrames=0.0d;
	private Double memFrag =0.0d;
	private Double dskFrag = 0.0d;
	private Integer ioClock = 0;
	private Integer pageFClock = 0;
	private Integer segFClock = 0;
	private Integer pageFNum = 0 ;
	private Integer segFNum = 0;
	private List<Integer> degMulPrg = new ArrayList<Integer>();
	private StringBuilder outSb = new StringBuilder();
	private List<TRACE> traceList = new ArrayList<TRACE>(); 
	
	public Double getMemUtilizFrames() {
		return memUtilizFrames;
	}
	public void setMemUtilizFrames(Double memUtilizFrames) {
		this.memUtilizFrames = memUtilizFrames;
	}
	public Double getMemUtilizWords() {
		return memUtilizWords;
	}
	public void setMemUtilizWords(Double memUtilizWords) {
		this.memUtilizWords = memUtilizWords;
	}
	public Double getDskUtilizWords() {
		return dskUtilizWords;
	}
	public void setDskUtilizWords(Double dskUtilizWords) {
		this.dskUtilizWords = dskUtilizWords;
	}
	public Double getDskUtilizFrames() {
		return dskUtilizFrames;
	}
	public void setDskUtilizFrames(Double dskUtilizFrames) {
		this.dskUtilizFrames = dskUtilizFrames;
	}
	public Double getMemFrag() {
		return memFrag;
	}
	public void setMemFrag(Double memFrag) {
		this.memFrag = memFrag;
	}
	public Double getDskFrag() {
		return dskFrag;
	}
	public void setDskFrag(Double dskFrag) {
		this.dskFrag = dskFrag;
	}
	public Integer getIoClock() {
		return ioClock;
	}
	public void increaseIoClock(Integer byVal) {
		this.ioClock = ioClock + byVal;
	}
	public Integer getPageFClock() {
		return pageFClock;
	}
	public void incrementPageFClock() {
		pageFClock = pageFClock +10 ;			//PF increased by 10
	}
	public Integer getSegFClock() {
		return segFClock;
	}
	public void incrementSegFClock() {
		segFClock = segFClock +5;				// SF increased by 5
	}
	public Integer getPageFNum() {
		return pageFNum;
	}
	public void incrementPageFNum() {
		pageFNum++;
	}
	public List<String> getOut() {
		return out;
	}
	public Set<Integer> getFrameSet() {
		return frameSet;
	}
	public Set<Integer> getPageSet() {
		return pageSet;
	}
	public Integer getSegFNum() {
		return segFNum;
	}
	public void incrementSegFNum() {
		segFNum++;
	}
	public StringBuilder getOutSb() {
		return outSb;
	}
	public List<String> getIn() {
		return in;
	}
	public List<TRACE> getTraceList() {
		return traceList;
	}
	

}
