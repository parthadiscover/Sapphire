
public class TEST {

	public static void main(String[] args) {
		
		System.out.println(":-D'");
		
		
		System.out.println("10".matches("^[0-1/-]{1}+$"));
		
		// TODO Auto-generated method stub
		System.out.println("ADERF0000000000000000".substring(1, 2));
		
		System.out.println(twosCompliment("1000000000000000"));
	//	System.out.println("0000000".matches("[0]+"));

	}
	
	
	public static String twosCompliment(String bin) {
		
		if(bin.trim().charAt(0)=='1' && bin.trim().substring(1).matches("[0]+")){
			return bin;
		}
        String twos = "", ones = "";

        for (int i = 0; i < bin.length(); i++) {
            ones += flip(bin.charAt(i));
        }
        int number0 = Integer.parseInt(ones, 2);
        StringBuilder builder = new StringBuilder(ones);
        boolean b = false;
        for (int i = ones.length() - 1; i > 0; i--) {
            if (ones.charAt(i) == '1') {
                builder.setCharAt(i, '0');
            } else {
                builder.setCharAt(i, '1');
                b = true;
                break;
            }
        }
        if (!b)
            builder.append("1", 0, 7);

        twos = builder.toString();

        return twos;
    }

// Returns '0' for '1' and '1' for '0'
    public static char flip(char c) {
        return (c == '0') ? '1' : '0';
    }

}
