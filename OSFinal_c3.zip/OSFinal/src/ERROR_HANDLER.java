/*
 * In Error Handler Class all errors and warning are executed using a switch case.
 * 
 * If any error or warning occurs while executing it will be showed in output file.
 * 
 * Handling the trace file
 */

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class ERROR_HANDLER {
	
	
	public static final int ER101 = 101;
	public static final int ER102 = 102;
	public static final int ER103 = 103;
	public static final int ER104 = 104;
	public static final int ER105 = 105;
	public static final int ER107 = 107;
	public static final int ER108 = 108;
	public static final int ER109 = 109;
	public static final int ER110 = 110;
	public static final int ER111 = 111;
	public static final int ER112 = 112;
	public static final int ER113 = 113;
	public static final int ER114 = 114;
	public static final int ER115 = 115;
	public static final int ER116 = 116;
	public static final int ER117 = 117;
	public static final int ER118 = 118;
	public static final int ER119 = 119;
	public static final int ER120 = 120;
	public static final int ER121 = 121;
	public static final int ER122 = 122;
	
	
	public static final int WR201 = 201;
	public static final int WR202 = 202;
	public static final int WR203 = 203;
	public static final int WR204 = 204;
	
	//**** In handle() switch case is used for error and warning messages ****//
	
	public static void handle(int code,String ...arg){
		
		String Errmsg = "";
		String Warnmsg = "";
		
		
		switch(code){
		
			case ER101 : 
				Errmsg = "ERROR ::(LOAD TIME) Loader input is not 4 words in Intermediate job lines ";
				break;
			case ER102 : 
				Errmsg = "ERROR ::(DECODING TIME) Zero Address Instruction "+arg[0]+" Not Found ";
				break;
			case ER103 : 
				Errmsg = "ERROR ::(DECODING TIME) One Address Instruction "+arg[0]+" Not Found ";
				break;
			case ER104 : 
				Errmsg = "ERROR ::(MEMORY-REF TIME) Cannot Retrieve Value From Mem Loc  "+arg[0] ;
				break;
			case ER105 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Some Fatal Error.Program terminated" ;
				break;
			case ER107 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Invalid Job Id Input" ;
				break;
			case ER108 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Invalid Load Address Input" ;
				break;
			case ER109 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Invalid Initial PC Input" ;
				break;
			case ER110 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Invalid Size Input" ;
				break;
			case ER111 : 
				Errmsg = "ERROR ::(MEMORY-REF TIME) Memory Overflow . Cannot reference size more than 256" ;
				break;
			case ER112 : 
				Errmsg = "ERROR ::(LOAD TIME) Job Params not correct. " ;
				break;
			case ER113 : 
				Errmsg = "ERROR ::(LOAD TIME) Job Does not Contain Program Segment. " ;
				break;
			case ER114 : 
				Errmsg = "ERROR ::(LOAD TIME) Job Does not Contain Input Segment. " ;
				break;
			case ER115 : 
				Errmsg = "ERROR ::(LOAD TIME) Job Does not Contain Finish Marking. " ;
				break;
			case ER116 : 
				Errmsg = "ERROR ::(LOAD TIME) Multiple Input Segment Found. " ;
				break;
			case ER117 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Stack overflow. " ;
				break;
			case ER118 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Stack underflow. " ;
				break;
			case ER119 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Incorrect Input. " ;
				break;
			case ER120 : 
				Errmsg = "ERROR ::(LOAD TIME) Incorrect JOB Structure . JOB_ID: " +arg[0];
				break;
			case ER121 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Segment Cannot Be Resolved For Disk Location : " +arg[0];
				break;			
			case ER122 : 
				Errmsg = "ERROR ::(EXECUTION TIME) Segment Fault Handling Failed For Segment  : " +arg[0];
				break;
			case WR201 : 
				Warnmsg = "WARNING :: Loader input less than 4 words in Intermediate job lines ";
				break;
			case WR202 : 
				Warnmsg = "WARNING ::(EXECUTION TIME) Invalid Trace Input" ;
				break;
			case WR203 : 
				Warnmsg = "WARNING ::(LOAD TIME) Program Segment less than 4 word . Padded with zero" ;
				break; 
			case WR204 : 
				Warnmsg = "WARNING ::(LOAD TIME) Input Segment not complete ." ;
				break; 
			default :
				Errmsg = "ERROR :: Some Fatal Error.Program terminated ";
				break;
		}
		
		if(!Errmsg.isEmpty()){
			throw new RuntimeException(Errmsg);
		}
		else if (!Warnmsg.isEmpty()){
			PrintStream current = System.out;
			SYSTEM.changeToOutput();
		
			System.out.println(Warnmsg);
			System.setOut(current);
		}
	}
	

}


