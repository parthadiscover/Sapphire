/*
 * 	In loader class one line is fetched from input file.
 * 	Each line split in 4 words.
 * 	Each word is stored in a buffer and from the buffer it is sent to the main memory.
 * 	Buffer size is 4( 4 for Hex).
 * trim function is used to split the words in loader.
 * Global Variable :-
 * discloc
 * 
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class LOADER {
	
	
	
	public static List<Queue<Integer>> frameSeqQueueList = new ArrayList<Queue<Integer>>();
	public static Queue<Integer> readyQueue = new LinkedList<Integer>();
	public static Queue<Integer> blockQueue = new LinkedList<Integer>();
	
	//public static Queue<Integer>[] frameSeqQueue = new 
	
	/*
	 * 
	 * 0 -> Page Num
	 * 1 -> Reference bit
	 * 2 -> Dirty bit
	 */
	
	public static int discLoc = 0;
	
	
	public static void init(){
		
		for(int i=0;i<3;i++)
			for(int j=0;j<3;j++)
				PCB.segmentTable[i][j] = -1;				//initialize
				
	
		
			for(int j=0;j<32;j++)
				for(int k=0;k<3;k++)
					PCB.pageFrameTable[j][k] = -1;       // Initialize	
			
		
	}
	
	
	

	
	public static void addSegmentTable(int index , int base , int length){
		
		PCB.segmentTable[index][0] = index;
		PCB.segmentTable[index][1] = base;
		PCB.segmentTable[index][2] = length;
		
		frameSeqQueueList.add(index, new LinkedList<Integer>());
		
		
	}
	
	
	//******** Loading to Memory Frames ********//
	
	
	public static void loadFrameToMemory(int frame,int segment){
	
		int page = PCB.pageFrameTable[frame][0];
		int dscpos = page * 8;
		int mempos = frame * 8;
		for(int i=0 ;i<8 ;i++){
			 char[] discVal = DISC.readFromDisk(dscpos + i);
			 MEMORY.memoryProc(1, (mempos + i), new String(discVal));
		}		
	}
	
	//************** Flashing to Disc **********//
	
	public static void flushFrameToDisk(int frame,int segment){
		int page = PCB.pageFrameTable[frame][0];
		int dscpos = page * 8;
		int mempos = frame * 8;
		for(int i=0 ;i<8 ;i++){
			String bin = MEMORY.readDirect(mempos + i);
			DISC.addToDisk(bin, dscpos+i);
			System.out.println("FLUSH PAGE EXEC :: DSKPOS -> "+ (dscpos+i) + " -MEMPOS-> "+(mempos + i) +"  -  " + bin);
		}	
		System.out.println("FLUSH FRAME EXEC :: "+dscpos);
	}
	

}
