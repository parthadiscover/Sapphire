import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/*
 * In PCB class frames are initialized.
 * Segment Table is Created here.
 * Page Map Table is Created here.
 * 
 */
public class PCB {
	
	

	/*//	pageFrame
	 * 
	 * 0 -> Page Num
	 * 1 -> Reference bit
	 * 2 -> Dirty bit
	 */
	
	/*
	 * Segment->
	 * 
	 * Page Table Index - Index No for Page table
	 * BaseAddr(memory frame)
	 * Length
	 * 
	 */
	
	public static int[][]segmentTable = new int[3][3];  //max segment 3 (program,input,output)
	
	public static int[][] pageFrameTable = new int[32][3]; 
	
	private static Map<Integer,PCB> pcbMapper = new HashMap<Integer,PCB>();
	
	private Integer jobId;
	private Integer programCounter = 0 ;
	private Integer inputCounter = 0 ;
	private Integer outputCounter = 0 ;
	private int programSegment = -1;
	private int inputSegment = -1;
	private int outputSegment = -1;
	private Integer loadAddrs;
	private Integer initialProgramCounter;
	private Integer jobSize;
	private Integer trace;
	private Integer prgmDskStartPos;
	private Integer prgmDskEndPos;
	private Integer inputDskStartPos;
	private Integer inputDskEndPos;
	private Integer outputDskStartPos;
	private Integer outputDskEndPos;
	private Integer inputSize = 0;
	private Integer outputSize = 0;
	private int tos = 0;
	private int[] stack = new int[7];
	private Integer	executedClockCycle = 0 ;
	
	
	private PCB(int jobId){
		this.jobId = jobId;
	}
	
	public static synchronized  PCB getInstance(Integer jobId){	
		
		if(!pcbMapper.containsKey(jobId)){
			pcbMapper.put(jobId,new PCB(jobId));
		}
		return pcbMapper.get(jobId);
}
	
	public Integer getJobId() {
		return jobId;
	}
	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}
	public int getProgramSegment() {
		return programSegment;
	}
	public void setProgramSegment(int programSegment) {
		this.programSegment = programSegment;
	}
	public int getInputSegment() {
		return inputSegment;
	}
	public void setInputSegment(int inputSegment) {
		this.inputSegment = inputSegment;
	}
	public int getOutputSegment() {
		return outputSegment;
	}
	public void setOutputSegment(int outputSegment) {
		this.outputSegment = outputSegment;
	}

	public Integer getProgramCounter() {
		return programCounter;
	}

	public void setProgramCounter(Integer programCounter) {
		this.programCounter = programCounter;
	}

	public Integer getLoadAddrs() {
		return loadAddrs;
	}

	public void setLoadAddrs(Integer loadAddrs) {
		this.loadAddrs = loadAddrs;
	}

	public Integer getInitialProgramCounter() {
		return initialProgramCounter;
	}

	public void setInitialProgramCounter(Integer initialProgramCounter) {
		this.initialProgramCounter = initialProgramCounter;
	}

	public Integer getJobSize() {
		return jobSize;
	}

	public void setJobSize(Integer jobSize) {
		this.jobSize = jobSize;
	}

	public Integer getTrace() {
		return trace;
	}

	public void setTrace(Integer trace) {
		this.trace = trace;
	}

	
	public Integer getInputDskStartPos() {
		return inputDskStartPos;
	}

	public void setInputDskStartPos(Integer inputDskStartPos) {
		this.inputDskStartPos = inputDskStartPos;
	}

	public Integer getInputDskEndPos() {
		return inputDskEndPos;
	}

	public void setInputDskEndPos(Integer inputDskEndPos) {
		this.inputDskEndPos = inputDskEndPos;
	}

	public Integer getPrgmDskStartPos() {
		return prgmDskStartPos;
	}

	public void setPrgmDskStartPos(Integer prgmDskStartPos) {
		this.prgmDskStartPos = prgmDskStartPos;
	}

	public Integer getPrgmDskEndPos() {
		return prgmDskEndPos;
	}

	public void setPrgmDskEndPos(Integer prgmDskEndPos) {
		this.prgmDskEndPos = prgmDskEndPos;
	}

	public Integer getInputCounter() {
		return inputCounter;
	}

	public void setInputCounter(Integer inputCounter) {
		this.inputCounter = inputCounter;
	}

	public Integer getExecutedClockCycle() {
		return executedClockCycle;
	}

	public void setExecutedClockCycle(Integer executedClockCycle) {
		this.executedClockCycle = executedClockCycle;
	}

	public Integer getOutputCounter() {
		return outputCounter;
	}

	public void setOutputCounter(Integer outputCounter) {
		this.outputCounter = outputCounter;
	}

	public Integer getOutputDskStartPos() {
		return outputDskStartPos;
	}

	public void setOutputDskStartPos(Integer outputDskStartPos) {
		this.outputDskStartPos = outputDskStartPos;
	}

	public Integer getOutputDskEndPos() {
		return outputDskEndPos;
	}

	public void setOutputDskEndPos(Integer outputDskEndPos) {
		this.outputDskEndPos = outputDskEndPos;
	}

	public Integer getInputSize() {
		return inputSize;
	}

	public void setInputSize(Integer inputSize) {
		this.inputSize = inputSize;
	}

	public Integer getOutputSize() {
		return outputSize;
	}

	public void setOutputSize(Integer outputSize) {
		this.outputSize = outputSize;
	}

	public int getTos() {
		return tos;
	}

	public void setTos(int tos) {
		this.tos = tos;
	}

	public int[] getStack() {
		return stack;
	}

	public void setStack(int[] stack) {
		this.stack = stack;
	}



}
