/*
 *  Global Variables
 *  1. jobId - It is in two digit HEX form and it gives the job id of the input loader format
 *  2. loadAddr - It is in two digit HEX form and it gives the base address of the input loader format
 *  3. initialPC - It is in two digit HEX  form and it shows the initial program counter from where loader input starts executing
 *  4. size - It is in two digit HEX form and it is the length of the job
 *  5. trace - It is in one digit HEX form and if it is enable it will create trace_file, where PC, IR, BR, TOS before and after, S[TOS] before and after is 
 *  
 *  -> The pages from DISC called to loader and send it to MEMORY.
 *  -> pages are loaded in frames.
 *  -> Storing Binary converted words in MainMemory.
 *  Handling Page Fault.
 *  Handling Segment Fault.
 *  
 *  
 */

import java.util.Deque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;

public class MEMORY {
	
	
	public static char MainMemory[][] = new char[256][16];
	

	
	public static Set<Integer> frameset = new HashSet<Integer>();
	public static Set<Integer> pageset = new HashSet<Integer>();
	
	//For reading disk address
	//For writing actual Memory address
	
	public static String memoryProc(int rw,int pos,String var){
		if(pos>255){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER111);
		}
		if(rw==1){		
			if(var.length()!=16){
				ERROR_HANDLER.handle(ERROR_HANDLER.ER101);
			}
			
			write(pos,var);
		
		}else{
			var = read(pos);
		}
		return var;
	}
	
	//****** Adding words to MainMemory (write) ******//


	private static void write(int pos,String bin){				
		MainMemory[pos] = bin.toCharArray();
	}
	
	//*********** Calculating Page location from DISC to get word address**********//
	
	public static void reswrite(int dskAddress,String bin){		
		
		System.out.println("POP WRITE ADR - "+dskAddress+" - "+bin);
		System.out.println("RD ADDR "+read(dskAddress));
				
			if(!read(dskAddress).isEmpty()){
				int segment = segmentFromDskAddrs(dskAddress);
				int page = pageNumFromDskAddrs(dskAddress);
				int frame = frameFromPageNum(page,segment);
				int posinmem = (frame * 8) + (dskAddress % 8);
				System.out.println("posinmem - "+posinmem);
				MainMemory[posinmem] = bin.toCharArray();								
				PCB.pageFrameTable[frame][2] = 1;			//update dirty bit
				System.out.println("ONE LAT READ "+dskAddress+" - "+read(dskAddress));			
			}			
	}
		
	
	private static String read(int dskAddr){
		

		int segment = segmentFromDskAddrs(dskAddr);
		int page = pageNumFromDskAddrs(dskAddr);
		int frame = frameFromPageNum(page,segment);

		System.out.println("SEGMENT :: " + segment +"  PAGE :: "+page+"  FRAME :: "+frame);
		
		int posinmem = 0;

		if(frame == -1){
			PAGEFAULT_HANDLER.handle(page,segment);      //Page Fault for No Page Found
			frame = frameFromPageNum(page,segment);
			posinmem = (frame * 8) + (dskAddr % 8);
		}else{			
			 posinmem = (frame * 8) + (dskAddr % 8);
			 PCB.pageFrameTable[frame][1] = 1;				//update reference bit
		}
		return new String(MainMemory[posinmem]);	
	}
	
	public static void mload(int dskAddr,int segment){
		
		int page = pageNumFromDskAddrs(dskAddr);
		int frame = frameFromPageNum(page,segment);
		LOADER.loadFrameToMemory(frame, segment);
	}
	
	
	
	
	
	//*******Printing MainMemory in Binary*******//
	
	public static void printMemorySnapshot(){	
		
		System.out.println("===================MEMORY SNAPSHOT=========================");
		for(int i = 0; i<MEMORY.MainMemory.length; i++)
		{
			System.out.print(i+"-->");
		    for(int j = 0; j<16; j++)		    
		        System.out.print(MEMORY.MainMemory[i][j]);		    
		    System.out.println();
		}		
		System.out.println("========================================================");
		
	}
	
	
	
	public static int segmentFromDskAddrs(int dskAddress){
		boolean isSegmentLoaded = false;
		int segment = resolveSegment(dskAddress);
		
		for(int i=0 ; i<3 ; i++){
			if(segment  == PCB.segmentTable[i][0]){
				isSegmentLoaded = true;
			}
		}
		
		if(!isSegmentLoaded){
			SEGMENT_FAULT.handle(segment);
		}
		return segment;
	}
	
	//*************** Getting page number from Disc Address ************//
	
	public static int pageNumFromDskAddrs(int dskAddress){
		int page = 0;
		if(dskAddress < 8)
			page = 0;
		else
			page = (dskAddress / 8);
		pageset.add(page);				//DNW
		return page;
	}
	
	//*************** Frames in MEMORY ***********//
	public static int frameFromPageNum(int pageNum,int segment){
		int frameNum = -1;		
		int segStartFrame = PCB.segmentTable[segment][1];
		int segSize = PCB.segmentTable[segment][2];
		for(int i=segStartFrame ; i<= (segStartFrame + segSize) ; i++){
			int temp[] = PCB.pageFrameTable[i];
			if(temp[0]==pageNum){
				frameNum = i;
			}
		}		
		return frameNum;
	}
	
	

	
	private static int resolveSegment(int dskAddress){
		
		int segment = -1;
		PCB pcb =  CPU.currentPCB;
		
		System.out.println("PRG START POS :: "+pcb.getPrgmDskStartPos());
		System.out.println("PRG END POS :: "+pcb.getPrgmDskEndPos());
		System.out.println("INP START POS :: "+pcb.getInputDskStartPos());
		System.out.println("INP END POS :: "+pcb.getInputDskEndPos());
		
		if(dskAddress >= pcb.getPrgmDskStartPos() && dskAddress <= pcb.getPrgmDskEndPos()){
			segment = 0;				// For Program Segment
		}else if(dskAddress >= pcb.getInputDskStartPos() && dskAddress <= pcb.getInputDskEndPos()){
			segment = 1;
		}else{
			ERROR_HANDLER.handle(ERROR_HANDLER.ER121, Integer.toString(dskAddress));
		}
		return  segment;
	}
	
	//*********** Memory Utilization **********//
	public static void  printMemoryUtilz(){
		
		int used = 0 ;
		for(int i = 0; i< MainMemory.length;i++){
				if(! new String(MainMemory[i]).trim().isEmpty()){
					used++;
				}
		}
		double ratio = (double)used/MainMemory.length;
		System.out.println("MEMORY UTILIZATION WORDS --  Ratio :"+ ratio + "  Percentage :"+(ratio *100) +"%");
		ratio = ((double)frameset.size()/32);
		System.out.println("MEMORY UTILIZATION FRAMES --  Ratio :"+ ratio + "  Percentage :"+(ratio *100) +"%");
	}
	
	//*************** Memory Fragmentation **************//
	
	public static void printMemFragmentation(){
		
		Deque deque = (Deque) LOADER.frameSeqQueueList.get(0);

		int lastframe = 31;
		int mempos = lastframe * 8;
		int pageno = PCB.pageFrameTable[lastframe][0];
		int emptyCount = 0;
		for(int i=0 ;i<8 ;i++){			
			 String item = new String(MainMemory[mempos + i]);
			 if(item.trim().isEmpty())
				 emptyCount++;			 
		}	
		int progEmptyCount = (8- (DISC.counter%8) - 1);
		
		System.out.println("MEMORY FRAGMENTATION :: "+emptyCount);
		
	}

}


//************** Handling Page Faults ************//
/*
 * Only 6 frames are available: 5, 8, 10, 17, 20, 31.
 */

 class PAGEFAULT_HANDLER {
	
	 public static int PF_CLOCK = 0;
	
	public static void handle(int page,int segment){
		System.out.println("PAGE FAULT OCCURED :: "+ page);
		
		CPU.BlockForIO();   // Block Job execution in Cpu
		
		SYSTEM.clock = SYSTEM.clock  + 10;
		PF_CLOCK = PF_CLOCK +10;
		SYSTEM.logClock();
		
		int segStartFrame = PCB.segmentTable[segment][1];
		int segSize = PCB.segmentTable[segment][2];
		System.out.println("SEG START FRAME :: "+segStartFrame+" SEG SIZE :: "+segSize);
		
		boolean pageReplReq = true;
	
			for(int i=segStartFrame ; i<= (segStartFrame + segSize) ; i++){
				if(isEmpty(PCB.pageFrameTable[i])){
					PCB.pageFrameTable[i] = new int[]{page,0,0};
					LOADER.frameSeqQueueList.get(segment).add(i) ;     //add frame to frame use sequence queue
					LOADER.loadFrameToMemory(i,segment);
					pageReplReq = false;
					break;
				}
			}	
		
			
		if(pageReplReq){			
			int frame = getReplacementFrame(segment);
			if(PCB.pageFrameTable[frame][2] == 1){
				LOADER.flushFrameToDisk(frame,segment);   // flush modified frame to Disk
			}
			PCB.pageFrameTable[frame] = new int[]{page,0,0};
			LOADER.loadFrameToMemory(frame,segment);			
		}
		
		CPU.UnBlockForIO();     // unblock execution in cpu
	}
	
	
	private static boolean isEmpty(int[] frmRow){
		return (frmRow[0] == -1 && frmRow[1] == -1  && frmRow[2] == -1);
	}
	
	//********** Replacing Frames or Pages *********//
	
	private static int getReplacementFrame(int segment){
		
		Queue<Integer> queue = LOADER.frameSeqQueueList.get(segment);
		Integer head = queue.peek();
		boolean iterFlag  = false;
			
		
		while(true){
	
			int item = queue.poll();		
			int[] frmTbEnt = PCB.pageFrameTable[item];
			if(frmTbEnt[1]== 1){
				if(iterFlag == true && head == item){    //  making sure when the queue has been completely iterated and all reference bits are 1 , Then replace the head element.
					return item;
				}else{
					queue.add(item);  // if ref bit is 1 then add at the bottom of the queue
				}
			}else{
				return item;
			}			
			iterFlag = true;
		}
	}	
	
}

//***************** Handling Segment Fault ***********//
 
class SEGMENT_FAULT {
		
		public static int SF_CLOCK= 0;
		
		
		public static void  handle(int segment){
			
			System.out.println("SEGMENT FAULT OCCURED :: "+segment);
				
			int val = (DISC.counter + (8-(DISC.counter % 8)));	
			if(PCB.segmentTable[segment][0] != segment){
				if(segment == 0){
					LOADER.addSegmentTable(segment,0,27);      // first 28 frames allocated to Program Segment
				}else if(segment == 1){
					LOADER.addSegmentTable(segment,28,1);		// 28,29 allocated to input segment
				}else if(segment == 1)
					LOADER.addSegmentTable(segment,28,1);		// 30,31 allocated to output segment
				}else{
					ERROR_HANDLER.handle(ERROR_HANDLER.ER122, Integer.toString(segment));
				}
				SYSTEM.clock = SYSTEM.clock  + 5;
				SF_CLOCK = SF_CLOCK +5;
				SYSTEM.logClock();
			}
}
		
	